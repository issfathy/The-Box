# import the Flask class from the flask module
from flask import Flask, render_template
from flask import Flask, render_template, redirect, url_for, request

# create the application object
app = Flask(__name__)

# use decorators to link the function to a url

@app.route('/', methods=['GET', 'POST'])
def welcome():
    return render_template('welcome.html')  # render a template

@app.route('/createAccount')
def createAccount():
    return render_template('createAccount.html')  # render a template

# Route for handling the login page logic
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] != 'shreya' or request.form['password'] != '1234':
            error = 'Invalid Credentials. Please try again.'
        else:
            return render_template('profile.html')
    return render_template('login.html', error=error)

@app.route('/test')
def test():
    return render_template('test.html')

# start the server with the 'run()' method
if __name__ == '__main__':
    app.run(debug=True)

    